<?php
// user setting
define('CONSUMER_KEY', 'x'); //isi
define('CONSUMER_SECRET', 'x'); //isi
define('access_token', '123-x'); //isi
define('access_token_secret', 'x'); //isi